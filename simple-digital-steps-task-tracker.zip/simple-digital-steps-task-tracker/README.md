# Simple Digital Steps — Task Tracker

A no-login, responsive task tracker built with HTML, CSS, vanilla JavaScript and Tailwind CSS (CDN). It can be installed on supported phones/desktops as a Progressive Web App (PWA).

## Features
- Dashboard for today's, this week's and this month's tasks
- Daily / weekly / monthly progress percentages
- Daily-task completion streak
- Create, edit, delete and complete tasks
- Categories: Study, Work, YouTube, Personal, Health
- Priority, due date/time and 10-minute reminder option
- Search and filters by category, priority, schedule, date and status
- Monthly calendar view
- Weekly completed-task chart and monthly summary
- Light and dark themes
- LocalStorage persistence and JSON backup export
- PWA manifest and service worker for installation/offline app shell

## Run locally (Windows)
1. Extract the ZIP file.
2. Install **Visual Studio Code** (optional but recommended).
3. Open the extracted `simple-digital-steps-task-tracker` folder in VS Code.
4. Install the VS Code extension **Live Server**.
5. Right-click `index.html` and choose **Open with Live Server**.
6. Your browser opens a local address similar to `http://127.0.0.1:5500`.

You can also run a simple local server if Python is installed:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

Do not open `index.html` directly with `file://` if you want PWA installation and browser notifications. Use localhost or HTTPS.

## Use on Android
1. Host the app on an HTTPS site (GitHub Pages or Netlify).
2. Open the hosted URL in Chrome on Android.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.
4. Allow notification permission if you want reminders.

## Free hosting: GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new public repository, for example `simple-digital-steps`.
3. Upload all files in this folder to the repository root (not the ZIP file).
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select `main` and `/ (root)`, then Save.
7. Wait for deployment. Your site URL will look like:
   `https://YOUR-USERNAME.github.io/simple-digital-steps/`

Alternative: Netlify
1. Sign in to Netlify.
2. Choose **Add new site → Deploy manually**.
3. Drag the extracted project folder into the deploy area.
4. Netlify gives you an HTTPS URL.

## Data and reminder notes
- Tasks are stored in the browser's LocalStorage on the device/browser you use. They do not automatically sync between your phone and laptop.
- Use **Export backup** regularly to download a JSON backup. Keep it somewhere safe.
- Browser notifications require permission and HTTPS (localhost is allowed for development).
- This starter version checks reminders while the app page is open. Browsers may pause background tabs, and notifications are not guaranteed if the app/browser is closed. Reliable closed-app reminders require a push-notification backend/service.
- The Tailwind CSS and Google Fonts CDN are used for styling, so first load needs internet access for those external resources. Core custom CSS and app logic are local.
- Tasks are individual scheduled instances. For a repeating daily/weekly/monthly routine, add a task for each date you want tracked. This preserves an honest completion history.
- Status is calculated as Done, Pending (not yet due), or Missed (past due and not marked done). A missed task can still be checked as done; it will then count as completed.

## Portfolio checklist
- Add screenshots of the dashboard, task form, calendar and reports to your portfolio.
- Add a short project description and list the technologies used.
- Link the live demo and GitHub repository.
- Include a short case study: problem, design choices, key features, local-first data approach and what you would improve next.
- Never upload your own real personal tasks to a public demo. Use sample tasks or a clean browser profile.

## Suggested future improvements
- Optional Firebase login and cloud sync
- True recurring task templates
- Push reminders while the app is closed
- Import backup button in the UI
- Unit tests and accessibility audit
