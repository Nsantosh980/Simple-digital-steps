(() => {
  "use strict";
  const STORAGE_KEY = "sds-task-tracker-v1";
  const THEME_KEY = "sds-task-theme";
  const $ = (id) => document.getElementById(id);
  let tasks = loadTasks();
  let currentView = "dashboard";
  let calendarCursor = new Date();
  let selectedDate = dateKey(new Date());
  let toastTimer;

  function loadTasks() {
    try { const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); return Array.isArray(data) ? data : []; }
    catch { return []; }
  }
  function saveTasks() { localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks)); }
  function dateKey(date) { const d = new Date(date); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; }
  function parseDue(task) { return new Date(task.due); }
  function isSameDay(a,b) { return dateKey(a) === dateKey(b); }
  function startOfWeek(date) { const d = new Date(date); d.setHours(0,0,0,0); d.setDate(d.getDate() - ((d.getDay()+6)%7)); return d; }
  function endOfWeek(date) { const d = startOfWeek(date); d.setDate(d.getDate()+7); return d; }
  function isInWeek(task,date=new Date()) { const d=parseDue(task); return d>=startOfWeek(date) && d<endOfWeek(date); }
  function isInMonth(task,date=new Date()) { const d=parseDue(task); return d.getFullYear()===date.getFullYear() && d.getMonth()===date.getMonth(); }
  function statusOf(task) {
    if (task.status === "Done") return "Done";
    if (parseDue(task).getTime() < Date.now()) return "Missed";
    return "Pending";
  }
  function fmtDate(date, opts={day:"numeric",month:"short"}) { return new Intl.DateTimeFormat("en-IN",opts).format(new Date(date)); }
  function fmtTime(date) { return new Intl.DateTimeFormat("en-IN",{hour:"numeric",minute:"2-digit"}).format(new Date(date)); }
  function escapeHTML(value="") { return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function showToast(message) {
    $("toast").textContent=message; $("toast").classList.add("show");
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>$("toast").classList.remove("show"),2600);
  }
  function percent(items) { return items.length ? Math.round(items.filter(t=>t.status==="Done").length/items.length*100) : 0; }
  function setProgress(prefix,items) {
    const done=items.filter(t=>t.status==="Done").length, p=items.length?Math.round(done/items.length*100):0;
    $(prefix+"Percent").textContent=p+"%"; $(prefix+"Count").textContent=`${done} of ${items.length} done`; $(prefix+"Bar").style.width=p+"%";
  }
  function itemHTML(task, full=false) {
    const status=statusOf(task), due=parseDue(task), isDone=status==="Done";
    return `<div class="task-item" data-task-id="${task.id}">
      <input class="task-check" type="checkbox" aria-label="Mark ${escapeHTML(task.name)} done" ${isDone?"checked":""} data-action="toggle">
      <div class="task-main"><div class="task-title ${isDone?"is-done":""}">${escapeHTML(task.name)}</div>
      <div class="task-meta"><span class="task-tag">${escapeHTML(task.category)}</span><span class="priority ${escapeHTML(task.priority)}">${escapeHTML(task.priority)}</span><span>${fmtDate(due)} · ${fmtTime(due)}</span>${status==="Missed"?'<span class="priority High">Missed</span>':""}</div>
      ${full && task.description?`<div class="task-meta">${escapeHTML(task.description)}</div>`:""}</div>
      ${full?`<div class="task-actions"><button class="mini-action" data-action="edit">Edit</button><button class="mini-action" data-action="delete">Delete</button></div>`:`<button class="task-menu" data-action="edit" aria-label="Edit task">⋯</button>`}
    </div>`;
  }
  function emptyHTML(title="Nothing here yet",hint="Add a task to get started.") { return `<div class="empty-state"><b>${title}</b>${hint}</div>`; }
  function renderDashboard() {
    const now=new Date(), daily=tasks.filter(t=>isSameDay(parseDue(t),now)), weekly=tasks.filter(t=>isInWeek(t,now)), monthly=tasks.filter(t=>isInMonth(t,now));
    setProgress("daily",daily); setProgress("weekly",weekly); setProgress("monthly",monthly);
    $("todayTaskCount").textContent=daily.length; $("weekTaskCount").textContent=weekly.length; $("monthTaskCount").textContent=monthly.length;
    $("todayTasks").innerHTML=daily.length?daily.sort(byDue).map(t=>itemHTML(t)).join(""):emptyHTML("A clear day","No tasks due today.");
    $("weekTasks").innerHTML=weekly.length?weekly.sort(byDue).slice(0,5).map(t=>itemHTML(t)).join(""):emptyHTML("Week is open","No tasks due this week.");
    $("monthTasks").innerHTML=monthly.length?monthly.sort(byDue).slice(0,5).map(t=>itemHTML(t)).join(""):emptyHTML("Fresh month","No tasks due this month.");
    const upcoming=tasks.filter(t=>statusOf(t)==="Pending").sort(byDue).slice(0,4);
    $("upcomingTasks").innerHTML=upcoming.length?upcoming.map(t=>itemHTML(t)).join(""):emptyHTML("You're all caught up","No upcoming pending tasks.");
    $("greeting").textContent=now.getHours()<12?"Let's make today count.":now.getHours()<17?"Keep your momentum going.":"A little progress still counts.";
    $("todayLabel").textContent=fmtDate(now,{weekday:"long",day:"numeric",month:"long"}).toUpperCase();
    $("streakCount").textContent=calculateStreak()+" days";
  }
  function byDue(a,b) { return parseDue(a)-parseDue(b); }
  function calculateStreak() {
    const dailyTasks=tasks.filter(t=>t.type==="Daily");
    if(!dailyTasks.length) return 0;
    const groups={};
    dailyTasks.forEach(t=>{const k=dateKey(parseDue(t));(groups[k]??=[]).push(t);});
    let cursor=new Date(); cursor.setHours(0,0,0,0);
    // A streak starts today if today's daily tasks are all done; otherwise allow yesterday.
    const todayKey=dateKey(cursor);
    if(groups[todayKey] && !groups[todayKey].every(t=>t.status==="Done")) cursor.setDate(cursor.getDate()-1);
    let streak=0;
    while(true){const k=dateKey(cursor), group=groups[k]; if(!group || !group.every(t=>t.status==="Done")) break; streak++; cursor.setDate(cursor.getDate()-1);}
    return streak;
  }
  function filteredTasks() {
    const q=$("globalSearch").value.trim().toLowerCase(), cat=$("categoryFilter").value, pri=$("priorityFilter").value, type=$("typeFilter").value, date=$("dateFilter").value, status=$("statusFilter").value;
    return tasks.filter(t=>(!q || (t.name+" "+t.description+" "+t.category).toLowerCase().includes(q))&&(!cat||t.category===cat)&&(!pri||t.priority===pri)&&(!type||t.type===type)&&(!date||dateKey(parseDue(t))===date)&&(!status||statusOf(t)===status)).sort(byDue);
  }
  function renderTasks() {
    const list=filteredTasks(); $("taskResultCount").textContent=`${list.length} task${list.length===1?"":"s"}`;
    $("allTasks").innerHTML=list.length?list.map(t=>itemHTML(t,true)).join(""):emptyHTML("No matching tasks","Try changing your filters or add a new task.");
  }
  function renderCalendar() {
    const year=calendarCursor.getFullYear(), month=calendarCursor.getMonth();
    $("calendarMonth").textContent=new Intl.DateTimeFormat("en-IN",{month:"long",year:"numeric"}).format(calendarCursor);
    const first=new Date(year,month,1), offset=(first.getDay()+6)%7, start=new Date(year,month,1-offset);
    const weekdays=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
    let html=weekdays.map(d=>`<div class="calendar-cell weekday">${d}</div>`).join("");
    for(let i=0;i<42;i++){
      const d=new Date(start); d.setDate(start.getDate()+i); const key=dateKey(d), dayTasks=tasks.filter(t=>dateKey(parseDue(t))===key);
      html+=`<button class="calendar-cell ${d.getMonth()!==month?"other-month":""} ${key===selectedDate?"selected":""} ${key===dateKey(new Date())?"today":""}" data-date="${key}" aria-label="${fmtDate(d,{day:"numeric",month:"long",year:"numeric"})}, ${dayTasks.length} tasks">
        <span class="day-number">${d.getDate()}</span><span class="calendar-dots">${dayTasks.slice(0,8).map(t=>`<i class="${t.status==="Done"?"done":""}"></i>`).join("")}</span></button>`;
    }
    $("calendarGrid").innerHTML=html; renderSelectedDate();
  }
  function renderSelectedDate() {
    const d=new Date(selectedDate+"T12:00:00"), list=tasks.filter(t=>dateKey(parseDue(t))===selectedDate).sort(byDue);
    $("selectedDateTitle").textContent=fmtDate(d,{weekday:"long",day:"numeric",month:"long"});
    $("selectedDateTasks").innerHTML=list.length?list.map(t=>itemHTML(t,true)).join(""):emptyHTML("No tasks on this date","Choose another day or add a task.");
  }
  function renderReports() {
    const now=new Date(), monthTasks=tasks.filter(t=>isInMonth(t,now)), done=monthTasks.filter(t=>t.status==="Done").length, pending=monthTasks.filter(t=>t.status==="Pending").length, missed=monthTasks.filter(t=>t.status==="Missed").length;
    const p=monthTasks.length?Math.round(done/monthTasks.length*100):0;
    $("reportPercent").textContent=p+"%"; $("reportDone").textContent=`${done} of ${monthTasks.length} tasks completed`; $("reportBar").style.width=p+"%";
    $("breakDone").textContent=done; $("breakPending").textContent=pending; $("breakMissed").textContent=missed;
    const monthStart=new Date(now.getFullYear(),now.getMonth(),1), weekBuckets=[];
    for(let d=new Date(monthStart);d<=now;){const s=new Date(d), e=new Date(d); e.setDate(e.getDate()+7); const end=new Date(Math.min(e.getTime(),now.getTime()+86400000)); weekBuckets.push({start:s,end,done:monthTasks.filter(t=>t.status==="Done"&&parseDue(t)>=s&&parseDue(t)<end).length}); d=e;}
    const best=weekBuckets.reduce((a,b)=>b.done>a.done?b:a,{done:0});
    $("bestWeek").textContent=best.done?`Week ${weekBuckets.indexOf(best)+1}`:"—";
    $("bestWeekDetail").textContent=best.done?`${best.done} completed tasks`:"No completed tasks yet";
    const ws=startOfWeek(now), days=[];
    for(let i=0;i<7;i++){const d=new Date(ws);d.setDate(ws.getDate()+i);const n=tasks.filter(t=>t.status==="Done"&&isSameDay(parseDue(t),d)).length;days.push({date:d,count:n});}
    const max=Math.max(1,...days.map(x=>x.count));
    $("weeklyChart").innerHTML=days.map(x=>`<div class="chart-col"><span class="chart-value">${x.count}</span><div class="chart-bar-wrap"><div class="chart-bar" style="height:${Math.max(3,x.count/max*100)}%"></div></div><span class="chart-label">${new Intl.DateTimeFormat("en-IN",{weekday:"short"}).format(x.date)}</span></div>`).join("");
  }
  function renderAll() { renderDashboard(); renderTasks(); renderCalendar(); renderReports(); }
  function openDialog(task=null) {
    $("taskForm").reset(); $("taskId").value=task?.id||"";
    $("dialogTitle").textContent=task?"Edit task":"Add a task";
    $("taskName").value=task?.name||""; $("taskDescription").value=task?.description||"";
    $("taskCategory").value=task?.category||"Study"; $("taskType").value=task?.type||"Daily"; $("taskPriority").value=task?.priority||"Medium";
    const d=task?parseDue(task):new Date(Date.now()+3600000);
    d.setMinutes(Math.ceil(d.getMinutes()/5)*5,0,0);
    $("taskDue").value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}T${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
    $("taskReminder").checked=task?task.reminder!==false:true;
    $("taskDialog").showModal(); $("taskName").focus();
  }
  function closeDialog() { $("taskDialog").close(); }
  function handleSubmit(event) {
    event.preventDefault();
    const id=$("taskId").value, name=$("taskName").value.trim(), due=$("taskDue").value;
    if(!name||!due){showToast("Please enter a task name and due date.");return;}
    const existing=tasks.find(t=>t.id===id);
    const task={id:id||crypto.randomUUID(),name,description:$("taskDescription").value.trim(),category:$("taskCategory").value,type:$("taskType").value,priority:$("taskPriority").value,due:new Date(due).toISOString(),reminder:$("taskReminder").checked,status:existing?.status||"Pending",createdAt:existing?.createdAt||new Date().toISOString(),remindedAt:null};
    if(existing){tasks=tasks.map(t=>t.id===id?task:t);showToast("Task updated.");}else{tasks.push(task);showToast("Task added.");}
    saveTasks(); closeDialog(); renderAll(); scheduleReminderCheck();
  }
  function handleAction(event) {
    const target=event.target.closest("[data-action]"); if(!target)return;
    const item=target.closest("[data-task-id]"); if(!item)return;
    const task=tasks.find(t=>t.id===item.dataset.taskId); if(!task)return;
    const action=target.dataset.action;
    if(action==="toggle"){task.status=target.checked?"Done":"Pending";saveTasks();renderAll();showToast(target.checked?"Nice work — task completed!":"Task marked as pending.");}
    if(action==="edit")openDialog(task);
    if(action==="delete"){if(confirm(`Delete "${task.name}"?`)){tasks=tasks.filter(t=>t.id!==task.id);saveTasks();renderAll();showToast("Task deleted.");}}
  }
  function setView(view) {
    currentView=view;
    document.querySelectorAll(".view").forEach(el=>el.classList.add("hidden"));
    $(`${view}View`).classList.remove("hidden");
    document.querySelectorAll(".side-nav .nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
    $("pageTitle").textContent=({dashboard:"Overview",tasks:"All tasks",calendar:"Calendar",reports:"Reports"})[view];
    if(view==="reports")renderReports(); if(view==="calendar")renderCalendar();
  }
  function setTheme(dark) {
    document.documentElement.classList.toggle("dark",dark); document.documentElement.classList.toggle("light",!dark);
    $("themeIcon").textContent=dark?"☀":"☾"; $("themeLabel").textContent=dark?"Light mode":"Dark mode";
    localStorage.setItem(THEME_KEY,dark?"dark":"light");
  }
  async function enableNotifications() {
    if(!("Notification" in window)){showToast("This browser does not support notifications.");return;}
    const permission=await Notification.requestPermission();
    if(permission==="granted"){showToast("Reminders enabled. Keep this app open for due-time checks.");scheduleReminderCheck();}
    else showToast("Notification permission was not granted.");
  }
  function scheduleReminderCheck() {
    if(!("Notification" in window)||Notification.permission!=="granted")return;
    const now=Date.now();
    tasks.forEach(task=>{
      if(!task.reminder||task.status==="Done"||task.remindedAt)return;
      const due=parseDue(task).getTime(), reminderAt=due-10*60*1000;
      if(now>=reminderAt && now<=due && due>now){
        new Notification("Task due soon",{body:`${task.name} is due at ${fmtTime(due)}.`,icon:"icon.svg",tag:task.id});
        task.remindedAt=new Date().toISOString(); saveTasks();
      }
    });
  }
  function exportBackup() {
    const blob=new Blob([JSON.stringify({app:"Simple Digital Steps Task Tracker",exportedAt:new Date().toISOString(),tasks},null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob), a=document.createElement("a"); a.href=url; a.download=`sds-task-backup-${dateKey(new Date())}.json`; a.click(); URL.revokeObjectURL(url); showToast("Backup exported.");
  }
  function importBackup(file) {
    const reader=new FileReader(); reader.onload=()=>{try{const data=JSON.parse(reader.result);if(!Array.isArray(data.tasks))throw new Error();if(confirm(`Import ${data.tasks.length} tasks? This replaces the current task list.`)){tasks=data.tasks;saveTasks();renderAll();showToast("Backup imported.");}}catch{showToast("That backup file could not be read.");}};reader.readAsText(file);
  }

  // Navigation and task actions use event delegation.
  document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
  document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.go)));
  document.addEventListener("click",e=>{if(e.target.closest("[data-action]"))handleAction(e);});
  ["addTaskTop","addTaskButton","calendarAdd"].forEach(id=>$(id).addEventListener("click",()=>openDialog()));
  $("closeDialog").addEventListener("click",closeDialog); $("cancelDialog").addEventListener("click",closeDialog);
  $("taskForm").addEventListener("submit",handleSubmit);
  ["globalSearch","categoryFilter","priorityFilter","typeFilter","dateFilter","statusFilter"].forEach(id=>$(id).addEventListener("input",renderTasks));
  $("clearFilters").addEventListener("click",()=>{["categoryFilter","priorityFilter","typeFilter","dateFilter","statusFilter","globalSearch"].forEach(id=>$(id).value="");renderTasks();});
  $("themeToggle").addEventListener("click",()=>setTheme(!document.documentElement.classList.contains("dark")));
  $("notifyButton").addEventListener("click",enableNotifications);
  $("prevMonth").addEventListener("click",()=>{calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar();});
  $("nextMonth").addEventListener("click",()=>{calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar();});
  $("todayMonth").addEventListener("click",()=>{calendarCursor=new Date();selectedDate=dateKey(new Date());renderCalendar();});
  $("calendarGrid").addEventListener("click",e=>{const cell=e.target.closest("[data-date]");if(cell){selectedDate=cell.dataset.date;calendarCursor=new Date(selectedDate+"T12:00:00");renderCalendar();}});
  $("exportButton").addEventListener("click",exportBackup);
  $("globalSearch").addEventListener("keydown",e=>{if(e.key==="Enter"){setView("tasks");renderTasks();}});
  // Import backup is available through the browser console helper: window.importSDSBackup(file).
  window.importSDSBackup=importBackup;
  if(localStorage.getItem(THEME_KEY)==="dark")setTheme(true);else setTheme(false);
  if("serviceWorker" in navigator && location.protocol!=="file:")navigator.serviceWorker.register("sw.js").catch(()=>{});
  renderAll();
  setInterval(scheduleReminderCheck,30000);
  scheduleReminderCheck();
})();
